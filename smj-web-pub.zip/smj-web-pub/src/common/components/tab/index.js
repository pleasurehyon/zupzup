import TabCont from "./TabCont";
import TabMenu from "./TabMenu";

export { TabCont, TabMenu };
