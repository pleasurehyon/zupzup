import "slick-carousel/slick/slick.css";
import "slick-carousel/slick/slick-theme.css";
import Slider from "react-slick";

function SlickNormal() {

    const settings = {
        arrows : true,
        dots : true,
        speed : 500,
        infinite : true,
        slidesToShow : 1,
        slidesToScroll : 1,
        centerMode : true,
        centerPadding : "0px"
      }

    return (
        <div style={{
            width : "50%",
            margin : "0 auto"
          }}>
            <Slider {...settings} >
              <div>
              <div style={{ backgroundColor : "red", width : "100%", height : "200px"}}>hihi</div>
              </div>
            <div>
            <div style={{ backgroundColor : "blue", width : "100%", height : "200px"}}>pppp</div>
            </div>
            
          </Slider>
          </div>
    );
}

export default SlickNormal
