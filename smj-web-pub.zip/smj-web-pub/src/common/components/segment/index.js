import SegmentControl from "./SegmentControl";
import SegmentWrap from "./SegmentWrap";

export { SegmentControl, SegmentWrap };
