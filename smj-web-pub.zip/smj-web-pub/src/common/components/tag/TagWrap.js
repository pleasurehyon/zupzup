/**
 * 
 * @name TagWrap
 * @role TagItem 하나 이상일 경우 감싸는 상위 컴포넌트입니다.
 * 
 */ 

// 2023-06-23 styled-components 제거
function TagWrap({ children }) {
    return (
        <div className="tag_wrap">{children}</div>
    );
}

export default TagWrap;
