import { useSelector } from "react-redux";

function PopupWebContainer() {

    const {message} = useSelector(state => state.popupReducer);

    return (
        <>
            {message}
        </>
    );
}

export default PopupWebContainer;
