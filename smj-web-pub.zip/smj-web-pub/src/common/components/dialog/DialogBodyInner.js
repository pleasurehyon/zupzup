function DialogBodyInner({ children }){

    return <div className="inner">{children}</div>;
}

export default DialogBodyInner;
